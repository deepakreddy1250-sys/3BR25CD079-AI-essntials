#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int number, guess;
    
    srand(time(0));
    number = rand() % 100 + 1;

    printf("Guess the number between 1 and 100\n");

    for (int i = 1; i <= 8; i++) {
        printf("Attempt %d: Enter your guess: ", i);
        scanf("%d", &guess);

        if (guess == number) {
            printf("Congratulations! You guessed the number!\n");
            return 0;
        }
        else if (guess < number) {
            printf("Too low!\n");
        }
        else {
            printf("Too high!\n");
        }
    }

    printf("You lost! The number was %d\n", number);

    return 0;
}